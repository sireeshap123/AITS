const Navbar = () => {
    return (
    
    <div className="navbar">
    <a href="#"> Contact Us </a>
    <a href="#">About Us| </a>
    <a href="#">Home |</a>
    </div>
    
    );
    }
    export default Navbar;