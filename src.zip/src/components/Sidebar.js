const Sidebar = () => {
    return (
    
    <div className="sidebabr">
    <span>
    Category inforamtion
    Sidebar
    </span>
    </div>
    );
    }
    export default Sidebar;